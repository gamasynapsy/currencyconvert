<?php
/* File : db.php
	 * Author : Gama Toko
	*/
/*******************************************************

    This program is free software; you can redistribute it and/or modify
    it as u need.
    * 
    * DATABASE name='currencies'
    * TABLE name='currency' (table containing rates) This should be updated through
    * a CRON process to be deployed on server..

 ******************************************************/ 
 
$db_host = "localhost";
$db_name = "currencies";
$db_user = "root"; // User of database to be changed according to yr own config
$db_pass = "";		// password to be changed according to yr own config

//Try to connect to the database
$db = new mysqli($db_host, $db_user, $db_pass, $db_name);
if (mysqli_connect_errno())
	fail("MySQL connect", mysqli_connect_error());	

if (!$db->set_charset("utf8"))
    printf("Error utf8 cant load: %s\n", $db->error);

function getcurrency(){ 
	global $db;
	global $id;
	global $curr;
	global $rate;
	global $getcurr; 
	$getcurr = $db->prepare("SELECT id,curr,rate FROM currency WHERE curr='".$curr."'");
	$getcurr->execute();
	$getcurr->store_result();
	$getcurr->bind_result($id,$curr,$rate); 
	$getcurr->fetch(); 
	return $rate;
}
	
?>
