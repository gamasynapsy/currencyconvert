<?php
/* File : converter.php
	 * Author : Gama Toko
	*/
/*******************************************************

    This program is free software; you can redistribute it and/or modify
    it as u need.
******************************************************/ 

	class Converter{
	
		public $rate;
		public $output;
		public $amount;


		/**
		 * Construction
		 */
		
		function __construct($rate, $amount) {
			// construction with currency and amount
			$this->rate=$rate;
			$this->amount=$amount;
		}
		
		/**
		 * Public method for access api.
		 * This convert dynamically
		 *
		 */
		public function convert(){
			$this->output=($this->amount/$this->rate);
			return $this->output;
		}
		
		/**
		 * Public method for access api.
		 * This revert dynamically
		 *
		 */
		public function reverse(){
			$this->output=($this->amount*$this->rate);
			return $this->output;
		}
		
			
	}
?>
